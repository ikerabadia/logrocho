Pasos a seguir para abrir el proyecto:
	1- importar la base de datos
	2- importar las llamadas de postman si se desea usar alguna de ellas
	3- meter la carpeta logrocho directamente dentro de htdocs
	4- en el archivo "model/bd.php" cambiar los parametros DB_INFO, DB_USER y DB_PASS 
		para que se conecte a tu base de datos
	5- para visualizar las paginas de error se debe acceder por ruta:
		- 404 -> /error404
		- 500 -> /error500
	
	Credenciales del usuario admin:
	User: admin
	password: admin