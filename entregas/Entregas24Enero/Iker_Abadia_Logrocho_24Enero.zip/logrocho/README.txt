Todas las llamadas de la api estan hechas para que funcionen con todos los datos de una entidad, 
en el caso de que haya ciertos datos de los que se dispongan en un cierto momento, se incluiran
en la llamada posteriormente de forma ajena al usuario, el cual no se dara cuenta.

Para importar las llamadas de postaman debes importar el archivo LOGROCHO.postman_collection.json 
en tu aplicacion de postman y te importara la coleccion de llamadas.